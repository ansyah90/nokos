# ANSYAHSELULER — Website Demo

## Isi
- `index.html` — halaman utama, katalog, dialog login/daftar, deposit demo, dan kontak CS.
- `style.css` — desain responsif gelap premium ungu-biru.
- `script.js` — pencarian, katalog, dialog, dan permintaan deposit demo.
- `assets/qris-kedai-ansyah.jpg` — gambar QRIS yang diberikan pemilik.

## Menjalankan
Buka `index.html` di browser untuk melihat prototipe. Untuk pengalaman terbaik dan pengembangan lebih lanjut, gunakan editor/kode lokal atau hosting statis.

## Penting
Versi ini adalah **front-end demo**, bukan sistem transaksi produksi:
- Login/pendaftaran belum terhubung ke backend.
- Permintaan deposit disimpan di localStorage browser dan tidak aman sebagai catatan produksi.
- Saldo tidak bertambah otomatis; admin harus memeriksa pembayaran langsung di aplikasi DANA Bisnis.
- Jangan gunakan sebagai sistem uang sungguhan sebelum ada backend, autentikasi, database, validasi pembayaran, dan kontrol anti-duplikasi.
- Harga negara adalah contoh tampilan, bukan penawaran supplier yang terverifikasi.
- Layanan nomor virtual harus digunakan secara sah dan sesuai ketentuan platform terkait.

Customer service WhatsApp: 081586977363
