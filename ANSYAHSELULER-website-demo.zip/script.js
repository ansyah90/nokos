const countries = [
  {name:"Indonesia",flag:"🇮🇩",price:5000,code:"ID"},
  {name:"Amerika Serikat",flag:"🇺🇸",price:8000,code:"US"},
  {name:"Inggris",flag:"🇬🇧",price:9000,code:"GB"},
  {name:"Kanada",flag:"🇨🇦",price:7000,code:"CA"},
  {name:"Jepang",flag:"🇯🇵",price:6000,code:"JP"},
  {name:"Jerman",flag:"🇩🇪",price:7000,code:"DE"},
  {name:"Australia",flag:"🇦🇺",price:7000,code:"AU"},
  {name:"Singapura",flag:"🇸🇬",price:6000,code:"SG"},
  {name:"Malaysia",flag:"🇲🇾",price:5000,code:"MY"},
  {name:"Thailand",flag:"🇹🇭",price:5000,code:"TH"}
];
const money = n => "Rp" + Number(n).toLocaleString("id-ID");
const countryGrid = document.getElementById("countryGrid");
const productGrid = document.getElementById("productGrid");
const waNumber = "6281586977363";
let toastTimer;
function showToast(message){
  const toast=document.getElementById("toast"); toast.textContent=message; toast.classList.add("show");
  clearTimeout(toastTimer); toastTimer=setTimeout(()=>toast.classList.remove("show"),3000);
}
function renderCatalog(query=""){
  const q=query.trim().toLocaleLowerCase("id");
  const filtered=countries.filter(c=>c.name.toLocaleLowerCase("id").includes(q)||c.code.toLowerCase().includes(q));
  countryGrid.innerHTML=filtered.length?filtered.map(c=>`<button class="country-card" data-country="${c.code}" aria-label="Lihat ${c.name}"><span class="flag">${c.flag}</span><strong>${c.name}</strong><small>${money(c.price)}</small></button>`).join(""):`<div class="empty-state">Negara tidak ditemukan. Coba kata kunci lain.</div>`;
  productGrid.innerHTML=filtered.length?filtered.slice(0,5).map((c,i)=>`<article class="product-card"><div class="product-visual"><span class="product-flag">${c.flag}</span>${i===0?'<span class="product-tag">Pilihan</span>':i===1?'<span class="product-tag">Populer</span>':''}</div><div class="product-body"><h3>${c.name}</h3><p>Nomor virtual · informasi layanan</p><div class="service-tags"><span>◉ Nomor bisnis</span><span>◎ SMS sesuai ketentuan</span></div><div class="product-price">${money(c.price)} <span class="tiny muted">/ estimasi</span></div><button class="btn btn-primary" data-order="${c.code}">Tanyakan Ketersediaan ↗</button></div></article>`).join(""):`<div class="empty-state">Produk tidak ditemukan.</div>`;
}
renderCatalog();
document.getElementById("year").textContent=new Date().getFullYear();
document.getElementById("searchForm").addEventListener("submit",e=>{e.preventDefault();renderCatalog(document.getElementById("searchInput").value);document.getElementById("produk").scrollIntoView({behavior:"smooth"});});
document.getElementById("searchFocus").addEventListener("click",()=>{document.getElementById("searchInput").focus();document.getElementById("beranda").scrollIntoView({behavior:"smooth"});});
countryGrid.addEventListener("click",e=>{const b=e.target.closest("[data-country]");if(!b)return;const c=countries.find(x=>x.code===b.dataset.country);if(c){document.getElementById("searchInput").value=c.name;renderCatalog(c.name);document.getElementById("produk").scrollIntoView({behavior:"smooth"});}});
productGrid.addEventListener("click",e=>{const b=e.target.closest("[data-order]");if(!b)return;const c=countries.find(x=>x.code===b.dataset.order);if(!c)return;document.getElementById("orderTitle").textContent=c.flag+" "+c.name;document.getElementById("orderDescription").textContent="Katalog demo untuk layanan nomor virtual. Konfirmasi tujuan penggunaan, ketersediaan, dan harga akhir kepada customer service.";document.getElementById("orderPrice").textContent=money(c.price)+" (estimasi)";document.getElementById("orderWhatsApp").href=`https://wa.me/${waNumber}?text=${encodeURIComponent("Halo CS ANSYAHSELULER, saya ingin bertanya tentang layanan nomor virtual "+c.name+". Mohon info ketersediaan, harga final, dan ketentuan penggunaan.")}`;document.getElementById("orderDialog").showModal();});
const authDialog=document.getElementById("authDialog");
function openAuth(mode){document.getElementById("authTitle").textContent=mode==="register"?"Daftar ANSYAHSELULER":"Masuk ANSYAHSELULER";document.getElementById("authMessage").textContent="";authDialog.showModal();}
document.getElementById("loginBtn").addEventListener("click",()=>openAuth("login"));
document.getElementById("registerBtn").addEventListener("click",()=>openAuth("register"));
document.getElementById("authSubmit").addEventListener("click",()=>{document.getElementById("authMessage").textContent="Ini hanya demo tampilan. Login dan pendaftaran perlu backend aman agar berfungsi sungguhan.";});
const depositDialog=document.getElementById("depositDialog");
document.getElementById("depositBtn").addEventListener("click",()=>depositDialog.showModal());
document.getElementById("depositSubmit").addEventListener("click",()=>{
  const amount=Number(document.getElementById("depositAmount").value);
  const user=document.getElementById("depositUser").value.trim();
  const ref=document.getElementById("depositRef").value.trim();
  const message=document.getElementById("depositMessage");
  if(!user){message.textContent="Isi nama pengguna atau ID pesanan terlebih dahulu.";return;}
  const request={amount,user,reference:ref,status:"Menunggu pemeriksaan admin",createdAt:new Date().toISOString()};
  try{
    const existing=JSON.parse(localStorage.getItem("ansyahseluler_deposit_requests")||"[]");
    existing.push(request);localStorage.setItem("ansyahseluler_deposit_requests",JSON.stringify(existing));
  }catch(err){message.textContent="Browser tidak dapat menyimpan demo permintaan ini. Silakan hubungi CS.";return;}
  message.textContent="Permintaan demo tersimpan di browser ini. Saldo belum ditambahkan; hubungi CS untuk pemeriksaan transaksi.";
  const text=`Halo CS ANSYAHSELULER, saya mengajukan konfirmasi deposit demo.%0AID/Nama: ${encodeURIComponent(user)}%0ANominal: ${encodeURIComponent(money(amount))}%0AReferensi: ${encodeURIComponent(ref||"-")}%0AMohon periksa pembayaran saya.`;
  showToast("Permintaan demo dicatat di browser.");
  // Provide explicit contact path without claiming payment verification.
  setTimeout(()=>{const link=document.createElement("a");link.href=`https://wa.me/${waNumber}?text=${text}`;link.target="_blank";link.rel="noopener";link.click();},250);
});
document.getElementById("menuToggle").addEventListener("click",()=>document.getElementById("mainNav").classList.toggle("open"));
document.querySelectorAll("#mainNav a").forEach(a=>a.addEventListener("click",()=>document.getElementById("mainNav").classList.remove("open")));
